#!/bin/bash
rm finkspack.zip
zip -r finkspack.zip assets pack.mcmeta pack.png compress.sh
echo done
zenity --info --title="finkspack" --text="done" --timeout=5